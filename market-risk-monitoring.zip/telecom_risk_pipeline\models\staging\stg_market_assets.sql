{{ config(
    materialized='view'
) }}

with source_data as (
    select *
    from {{ source('raw_mds', 'MARKET_ASSETS') }}
)

select * from source_data
