{{ config(
    materialized='table'
) }}

with asset_price_drops as (
    select *
    from {{ ref('int_asset_price_analysis') }}
),

supply_chain_impact as (
    select *
    from {{ ref('stg_supply_chain_impact') }}
),

joined_data as (
    select
        apd.*,
        sci.impact_id,
        sci.region,
        sci.risk_level,
        sci.last_updated,
        round(apd.price_drop_percentage * 100, 2) as price_drop_pct,
        case
            when apd.price_drop_percentage > 0.10 and sci.risk_level = 'High'
            then true
            else false
        end as is_critical_alert
    from asset_price_drops apd
    inner join supply_chain_impact sci
        on apd.asset_id = sci.asset_id
)

select * from joined_data
