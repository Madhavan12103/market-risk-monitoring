{{ config(
    materialized='view'
) }}

with source_data as (
    select
        cast(timestamp as timestamp) as ticked_at,
        *
    from {{ source('raw_mds', 'PRICE_TICKERS') }}
)

select * from source_data
