{{ config(
    materialized='view'
) }}

with source_data as (
    select *
    from {{ source('raw_mds', 'SUPPLY_CHAIN_IMPACT') }}
)

select * from source_data
