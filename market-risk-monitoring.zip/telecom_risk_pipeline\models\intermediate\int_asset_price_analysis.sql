{{ config(
    materialized='table'
) }}

with market_assets as (
    select *
    from {{ ref('stg_market_assets') }}
),

price_tickers as (
    select *
    from {{ ref('stg_price_tickers') }}
),

joined_data as (
    select
        ma.*,
        pt.ticker_id,
        pt.current_price,
        pt.volatility_index,
        pt.ticked_at,
        round(
            (ma.base_price - pt.current_price) / ma.base_price,
            4
        ) as price_drop_percentage
    from market_assets ma
    inner join price_tickers pt
        on ma.asset_id = pt.asset_id
    where pt.volatility_index > 0.5
)

select * from joined_data
