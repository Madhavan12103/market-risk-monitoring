from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.python import PythonOperator
import snowflake.connector
import logging
import subprocess
import os

# Default arguments for the DAG
default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2024, 1, 1),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

# Define the DAG
dag = DAG(
    'market_risk_monitoring',
    default_args=default_args,
    description='Daily market risk monitoring DAG',
    schedule_interval='0 0 * * *',  # Daily at midnight
    catchup=False,
    tags=['market', 'risk', 'monitoring'],
)

# Task 1: Run dbt models (using PythonOperator for Windows compatibility)
def run_dbt():
    """Run dbt models using subprocess"""
    try:
        # Change to telecom_risk_pipeline directory
        os.chdir('telecom_risk_pipeline')

        # Run dbt run
        result = subprocess.run(['dbt', 'run'], capture_output=True, text=True, shell=True)

        if result.returncode == 0:
            logging.info("dbt run completed successfully")
            logging.info(result.stdout)
        else:
            logging.error(f"dbt run failed with return code {result.returncode}")
            logging.error(result.stderr)
            raise Exception(f"dbt run failed: {result.stderr}")

    except Exception as e:
        logging.error(f"Error running dbt: {str(e)}")
        raise e

dbt_run = PythonOperator(
    task_id='dbt_run',
    python_callable=run_dbt,
    dag=dag,
)

# Task 2: Check for critical risk alerts
def check_critical_alerts():
    # Snowflake connection parameters
    conn_params = {
        'account': 'EJAPPKE-TR63466',
        'user': 'MADHAVAN03',
        'password': 'Sreetharansathya03',
        'role': 'ACCOUNTADMIN',
        'database': 'MDS_PROJECT',
        'warehouse': 'COMPUTE_WH',
        'schema': 'RAW'
    }

    # Connect to Snowflake
    conn = snowflake.connector.connect(**conn_params)
    cursor = conn.cursor()

    try:
        # Execute the query
        cursor.execute("""
            SELECT COUNT(*) 
            FROM MDS_PROJECT.RAW_MART.FCT_RISK_ALERTS 
            WHERE IS_CRITICAL_ALERT = TRUE
        """)

        # Fetch the result
        result = cursor.fetchone()
        count = result[0] if result else 0

        # Check if critical alerts exist
        if count > 0:
            logging.warning(f'CRITICAL: High-risk market events detected! Count: {count}')
        else:
            logging.info(f'No critical alerts detected. Count: {count}')

    except Exception as e:
        logging.error(f'Error checking critical alerts: {str(e)}')
        raise e

    finally:
        cursor.close()
        conn.close()

risk_check = PythonOperator(
    task_id='risk_check',
    python_callable=check_critical_alerts,
    dag=dag,
)

# Set task dependencies
dbt_run >> risk_check
